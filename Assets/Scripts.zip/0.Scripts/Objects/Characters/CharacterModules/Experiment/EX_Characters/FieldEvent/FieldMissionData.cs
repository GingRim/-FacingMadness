using UnityEngine;
using System.Collections.Generic;


[CreateAssetMenu(fileName = "FieldMission", menuName = "Facing Madness/Field/Mission")]
public class FieldMissionData : ScriptableObject
{
    [Header("미션 식별 정보")]
    [SerializeField] private string missionId;
    [SerializeField] private string missionName;

    [TextArea(3, 8)]
    [SerializeField] private string description;
    
    [Header("미션 표시")]
    [SerializeField] private Sprite missionImage;

    [Header("필드 오브젝트")]
    [SerializeField]
    private string fieldObjectName;

    [Header("미션 클리어 목표")]
    [SerializeField]
    private List<FieldMissionObjectiveRequirement> objectives = new();

    public IReadOnlyList<FieldMissionObjectiveRequirement> Objectives => objectives;

    public string FieldObjectName => fieldObjectName;

    public string MissionId => missionId;
    public string MissionName => missionName;
    public string Description => description;
    public Sprite MissionImage => missionImage;

}